//
//  BillSplitterApp.swift
//  BillSplitter
//
//  Created by Austin Bond on 6/4/24.
//

import SwiftUI

@main
struct BillSplitterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
